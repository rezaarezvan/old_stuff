

public class Main
{
	public static void main(String[] args){
	    
	    Hund h1 = new Hund("Sch�fer", "tik", 5);
	    Hund h2 = new Hund("pudel", "hane", 3);
	    
	    h1.skrivUt();
	    h2.skrivUt();
	}
}
