

public class Main_rektangel
{
	public static void main(String[] args){
	    
	    Rektangel r1 = new Rektangel(5,7);
	    Rektangel r2 = new Rektangel(17,54);
	    
	    r1.visaEgenskaper();
	    r1.visaOmkrets();
	    r1.visaArea();
	    
	    r2.visaEgenskaper();
	    r2.visaOmkrets();
	    r2.visaArea();
	}
}
