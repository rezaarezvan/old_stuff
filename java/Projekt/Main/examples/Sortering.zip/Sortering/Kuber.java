public class Kuber{
    public static void main(String[] args){
        int val = Kbd.readInt("Vilken sidlängd ska vara max?");

        int sidor = val;
        int total = 0;
        if(val >= 2 || val <= 40){
            for(int i = 1; i <= val; i++){
                total += (i*i*i);

            }
            System.out.print(total);
        }
    }
}